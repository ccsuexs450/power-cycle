import time

# this file was only used for testing. This not needed for full functionality
def resultsT(path, email):
    values = [750, 167, 125, 83.7, "../docs/graph/nickp2019-05-01 19_20_44.620382.png"]
    time.sleep(1)
    return values

def power_input_test(email):
    path_test = "./data/sensordata/power.txt"
    return path_test

def calibrate_input_test():
    path_test = "./data/sensordata/calibrate.txt"
    return path_test
